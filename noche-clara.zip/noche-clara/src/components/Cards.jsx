import React from 'react'

export function BenefitCard({ icon, title, description }) {
  return (
    <div
      className="glass-card-light p-5 group transition-all duration-300"
      style={{ cursor: 'default' }}
      onMouseOver={e => {
        e.currentTarget.style.border = '1px solid rgba(155,143,212,0.2)'
        e.currentTarget.style.transform = 'translateY(-3px)'
      }}
      onMouseOut={e => {
        e.currentTarget.style.border = '1px solid rgba(200,192,232,0.08)'
        e.currentTarget.style.transform = 'translateY(0)'
      }}
    >
      <div className="text-2xl mb-3">{icon}</div>
      <h4
        className="text-cream-100 mb-1.5"
        style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '18px', fontWeight: 400 }}
      >
        {title}
      </h4>
      <p className="text-cream-300/50 text-sm leading-relaxed" style={{ fontWeight: 300 }}>
        {description}
      </p>
    </div>
  )
}

export function FeatureCard({ icon, title, description }) {
  return (
    <div
      className="group transition-all duration-300"
      style={{
        padding: '20px',
        borderRadius: '12px',
        background: 'rgba(14,22,40,0.5)',
        border: '1px solid rgba(200,192,232,0.07)',
        cursor: 'default',
      }}
      onMouseOver={e => {
        e.currentTarget.style.background = 'rgba(14,22,40,0.8)'
        e.currentTarget.style.borderColor = 'rgba(155,143,212,0.15)'
      }}
      onMouseOut={e => {
        e.currentTarget.style.background = 'rgba(14,22,40,0.5)'
        e.currentTarget.style.borderColor = 'rgba(200,192,232,0.07)'
      }}
    >
      <div
        className="mb-3 flex items-center justify-center"
        style={{
          width: '36px',
          height: '36px',
          borderRadius: '8px',
          background: 'rgba(155,143,212,0.1)',
          border: '1px solid rgba(155,143,212,0.15)',
        }}
      >
        <span style={{ fontSize: '16px' }}>{icon}</span>
      </div>
      <h4
        className="text-cream-100 mb-1.5"
        style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '17px', fontWeight: 400 }}
      >
        {title}
      </h4>
      <p className="text-cream-300/45 text-xs leading-relaxed" style={{ fontWeight: 300 }}>
        {description}
      </p>
    </div>
  )
}
