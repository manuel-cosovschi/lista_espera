import React, { useState, useEffect } from 'react'
import { getWaitlistStats } from '../lib/waitlist'

export default function AdminPanel() {
  const [secret, setSecret] = useState('')
  const [authenticated, setAuthenticated] = useState(false)
  const [stats, setStats] = useState(null)
  const [loading, setLoading] = useState(false)
  const [launching, setLaunching] = useState(false)
  const [launchResult, setLaunchResult] = useState(null)
  const [error, setError] = useState('')

  const handleLogin = (e) => {
    e.preventDefault()
    // Simple client-side check — the real verification happens server-side in the API
    if (secret.trim()) {
      setAuthenticated(true)
      loadStats()
    }
  }

  const loadStats = async () => {
    setLoading(true)
    try {
      const data = await getWaitlistStats()
      setStats(data)
    } catch (err) {
      setError('Error al cargar datos: ' + err.message)
    } finally {
      setLoading(false)
    }
  }

  const handleSendLaunch = async () => {
    if (!window.confirm('¿Confirmar envío de emails de lanzamiento?')) return
    setLaunching(true)
    setLaunchResult(null)
    try {
      const res = await fetch('/api/send-launch-emails', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminSecret: secret }),
      })
      const data = await res.json()
      setLaunchResult(data)
      loadStats()
    } catch (err) {
      setLaunchResult({ error: err.message })
    } finally {
      setLaunching(false)
    }
  }

  if (!authenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center px-6">
        <div className="glass-card p-8 w-full max-w-sm">
          <h1
            className="text-cream-100 mb-6"
            style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '28px', fontWeight: 400, textAlign: 'center' }}
          >
            Admin · Noche Clara
          </h1>
          <form onSubmit={handleLogin} className="space-y-4">
            <input
              type="password"
              placeholder="Clave de administrador"
              value={secret}
              onChange={e => setSecret(e.target.value)}
              className="input-night"
            />
            <button type="submit" className="btn-primary w-full">
              Entrar
            </button>
          </form>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen px-6 py-12 max-w-4xl mx-auto">
      <h1 className="text-cream-100 mb-8" style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '36px', fontWeight: 400 }}>
        Panel de Admin
      </h1>

      {error && <p className="text-red-400/80 mb-4 text-sm">{error}</p>}

      {loading ? (
        <p className="text-cream-300/40">Cargando…</p>
      ) : stats ? (
        <>
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
            <div className="glass-card p-5 text-center">
              <div style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '48px', fontWeight: 300, color: '#C8C0E8' }}>
                {stats.count}
              </div>
              <div className="text-cream-300/40 text-xs">personas en lista</div>
            </div>
            <div className="glass-card p-5 text-center">
              <div style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '48px', fontWeight: 300, color: '#C9A84C' }}>
                {stats.recent.filter(r => !r.launch_email_sent).length}
              </div>
              <div className="text-cream-300/40 text-xs">sin email de lanzamiento</div>
            </div>
            <div className="glass-card p-5 text-center col-span-2 md:col-span-1">
              <div style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '48px', fontWeight: 300, color: '#9B8FD4' }}>
                {stats.recent.filter(r => r.confirmation_email_sent).length}
              </div>
              <div className="text-cream-300/40 text-xs">confirmación enviada</div>
            </div>
          </div>

          {/* Launch button */}
          <div className="glass-card p-6 mb-8">
            <h2 className="text-cream-100 mb-2" style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '22px', fontWeight: 400 }}>
              Email de lanzamiento
            </h2>
            <p className="text-cream-300/40 text-sm mb-4">
              Envía el email de lanzamiento a todos los usuarios con <code className="text-lavender-300">launch_email_sent = false</code>.
            </p>
            <button
              onClick={handleSendLaunch}
              disabled={launching}
              className="btn-primary disabled:opacity-50"
            >
              {launching ? 'Enviando…' : '🚀 Enviar email de lanzamiento'}
            </button>
            {launchResult && (
              <div className="mt-4 p-4 rounded-xl" style={{ background: launchResult.error ? 'rgba(255,80,80,0.1)' : 'rgba(155,143,212,0.1)', border: '1px solid rgba(155,143,212,0.15)' }}>
                <pre className="text-cream-300/70 text-xs overflow-auto">{JSON.stringify(launchResult, null, 2)}</pre>
              </div>
            )}
          </div>

          {/* Recent records */}
          <div className="glass-card p-6">
            <h2 className="text-cream-100 mb-4" style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '22px', fontWeight: 400 }}>
              Últimos registros
            </h2>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="text-cream-300/30 border-b border-white/5">
                    <th className="text-left pb-2 pr-4 font-normal">Nombre</th>
                    <th className="text-left pb-2 pr-4 font-normal">Email</th>
                    <th className="text-left pb-2 pr-4 font-normal">Estado</th>
                    <th className="text-left pb-2 pr-4 font-normal">Confirmación</th>
                    <th className="text-left pb-2 font-normal">Lanzamiento</th>
                  </tr>
                </thead>
                <tbody>
                  {stats.recent.map(r => (
                    <tr key={r.id} className="border-b border-white/5">
                      <td className="py-2 pr-4 text-cream-100/70">{r.name}</td>
                      <td className="py-2 pr-4 text-cream-300/50 font-mono">{r.email}</td>
                      <td className="py-2 pr-4">
                        <span style={{ color: '#C8C0E8', background: 'rgba(155,143,212,0.1)', padding: '2px 8px', borderRadius: '99px' }}>
                          {r.status}
                        </span>
                      </td>
                      <td className="py-2 pr-4">{r.confirmation_email_sent ? '✓' : '—'}</td>
                      <td className="py-2">{r.launch_email_sent ? '✓' : '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : null}
    </div>
  )
}
