import React, { useState } from 'react'

const faqs = [
  {
    q: '¿Qué es Noche Clara?',
    a: 'Una plataforma digital de bienestar para acompañarte durante 21 noches con rutina nocturna, tracker, diario, audios y recursos.',
  },
  {
    q: '¿Cuándo abre?',
    a: 'Muy pronto. Las personas en lista de espera serán las primeras en enterarse.',
  },
  {
    q: '¿Qué beneficio recibo por anotarme?',
    a: 'Acceso anticipado y una tarifa especial de lanzamiento con 70% de descuento.',
  },
  {
    q: '¿Es una app médica?',
    a: 'No. Es un producto educativo de bienestar y hábitos. No reemplaza atención médica ni psicológica profesional.',
  },
  {
    q: '¿Cómo voy a recibir el acceso?',
    a: 'Te enviaremos un email con el link de acceso y pago cuando abramos el lanzamiento.',
  },
]

export default function FAQ() {
  const [open, setOpen] = useState(null)

  return (
    <section className="section-padding py-24">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-14">
          <p className="text-lavender-400 text-xs tracking-widest uppercase mb-3">Preguntas</p>
          <h2
            style={{
              fontFamily: 'Cormorant Garamond, serif',
              fontSize: 'clamp(32px, 5vw, 48px)',
              fontWeight: 400,
              color: '#F7F1E3',
            }}
          >
            Lo que querés saber
          </h2>
        </div>

        <div className="space-y-2">
          {faqs.map((faq, i) => (
            <div
              key={i}
              style={{
                background: 'rgba(14,22,40,0.5)',
                border: '1px solid rgba(200,192,232,0.07)',
                borderRadius: '12px',
                overflow: 'hidden',
                transition: 'border-color 0.2s ease',
                borderColor: open === i ? 'rgba(155,143,212,0.2)' : 'rgba(200,192,232,0.07)',
              }}
            >
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="w-full flex items-center justify-between px-6 py-4 text-left"
                style={{ background: 'none', border: 'none', cursor: 'pointer' }}
              >
                <span
                  style={{
                    fontFamily: 'Cormorant Garamond, serif',
                    fontSize: '18px',
                    fontWeight: 400,
                    color: '#F7F1E3',
                  }}
                >
                  {faq.q}
                </span>
                <span
                  style={{
                    color: 'rgba(155,143,212,0.6)',
                    fontSize: '18px',
                    transition: 'transform 0.3s ease',
                    transform: open === i ? 'rotate(45deg)' : 'none',
                    flexShrink: 0,
                    marginLeft: '16px',
                  }}
                >
                  +
                </span>
              </button>
              {open === i && (
                <div
                  className="px-6 pb-4"
                  style={{
                    color: 'rgba(247,241,227,0.55)',
                    fontSize: '14px',
                    lineHeight: '1.7',
                    fontWeight: 300,
                    animation: 'fadeUp 0.3s ease forwards',
                  }}
                >
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
