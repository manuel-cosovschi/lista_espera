import React, { useState, useEffect } from 'react'

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-500"
      style={{
        background: scrolled ? 'rgba(6,11,24,0.9)' : 'transparent',
        backdropFilter: scrolled ? 'blur(12px)' : 'none',
        borderBottom: scrolled ? '1px solid rgba(200,192,232,0.08)' : 'none',
      }}
    >
      <div className="max-w-6xl mx-auto px-6 md:px-12 py-5 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-2.5">
          <div
            style={{
              width: '28px',
              height: '28px',
              borderRadius: '50%',
              background: 'linear-gradient(135deg, rgba(200,192,232,0.3) 0%, transparent 60%)',
              border: '1px solid rgba(200,192,232,0.35)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <path
                d="M7 1C7 1 5 4 5 7C5 10 7 13 7 13C7 13 9 10 9 7C9 4 7 1 7 1Z"
                fill="rgba(200,192,232,0.6)"
              />
              <circle cx="7" cy="7" r="2" fill="rgba(232,213,160,0.7)" />
            </svg>
          </div>
          <span
            className="text-cream-100 tracking-wide"
            style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '18px', fontWeight: 400 }}
          >
            Noche Clara
          </span>
        </div>

        {/* Badge */}
        <div
          className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full"
          style={{
            background: 'rgba(155,143,212,0.1)',
            border: '1px solid rgba(155,143,212,0.2)',
          }}
        >
          <span
            className="w-1.5 h-1.5 rounded-full bg-lavender-400 animate-pulse-slow"
          />
          <span className="text-lavender-300 text-xs tracking-wider" style={{ fontWeight: 400 }}>
            Lista de espera abierta
          </span>
        </div>
      </div>
    </nav>
  )
}
