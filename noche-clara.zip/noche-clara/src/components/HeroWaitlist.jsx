import React, { useState } from 'react'
import WaitlistForm from './WaitlistForm'
import SuccessMessage from './SuccessMessage'
import PlatformMockup from './PlatformMockup'

export default function HeroWaitlist() {
  const [success, setSuccess] = useState(false)
  const [successData, setSuccessData] = useState(null)

  const handleSuccess = (data) => {
    setSuccessData(data)
    setSuccess(true)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <section className="relative min-h-screen flex flex-col justify-center pt-24 pb-20 section-padding">
      {/* Gradient orbs */}
      <div
        className="absolute pointer-events-none"
        style={{
          top: '20%',
          left: '-10%',
          width: '500px',
          height: '500px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(155,143,212,0.08) 0%, transparent 70%)',
          filter: 'blur(40px)',
        }}
      />
      <div
        className="absolute pointer-events-none"
        style={{
          bottom: '10%',
          right: '-5%',
          width: '400px',
          height: '400px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(201,168,76,0.06) 0%, transparent 70%)',
          filter: 'blur(40px)',
        }}
      />

      <div className="relative z-10 max-w-6xl mx-auto w-full">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left col */}
          <div>
            {/* Badge */}
            <div
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-8"
              style={{
                background: 'rgba(155,143,212,0.1)',
                border: '1px solid rgba(155,143,212,0.2)',
                animation: 'fadeUp 0.6s ease 0.1s both',
              }}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-lavender-400 animate-pulse-slow" />
              <span className="text-lavender-300 text-xs tracking-widest uppercase">
                Lista de espera abierta
              </span>
            </div>

            {/* Headline */}
            <h1
              className="mb-6"
              style={{
                fontFamily: 'Cormorant Garamond, serif',
                fontSize: 'clamp(38px, 6vw, 68px)',
                fontWeight: 400,
                lineHeight: 1.1,
                color: '#F7F1E3',
                animation: 'fadeUp 0.6s ease 0.2s both',
              }}
            >
              Tu rutina nocturna,{' '}
              <em
                style={{
                  fontStyle: 'italic',
                  background: 'linear-gradient(135deg, #C8C0E8 0%, #9B8FD4 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                }}
              >
                en una sola plataforma
              </em>
            </h1>

            {/* Subheadline */}
            <p
              className="text-cream-300/60 leading-relaxed mb-10"
              style={{
                fontSize: 'clamp(15px, 2vw, 17px)',
                fontWeight: 300,
                maxWidth: '480px',
                animation: 'fadeUp 0.6s ease 0.35s both',
              }}
            >
              Estamos preparando una experiencia digital de 21 noches para ayudarte a ordenar tu descanso, bajar revoluciones y construir una rutina nocturna más estable.
            </p>

            {/* Form */}
            <div style={{ animation: 'fadeUp 0.6s ease 0.5s both' }}>
              {success ? (
                <SuccessMessage name={successData?.name} />
              ) : (
                <div className="glass-card p-6 glow-lavender">
                  <WaitlistForm onSuccess={handleSuccess} />
                  <p
                    className="text-cream-300/35 text-xs mt-4 leading-relaxed"
                    style={{ fontWeight: 300 }}
                  >
                    Los primeros usuarios recibirán acceso anticipado con 70% de descuento durante el lanzamiento.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Right col — mockup */}
          <div
            className="hidden lg:flex justify-center"
            style={{ animation: 'fadeUp 0.8s ease 0.4s both' }}
          >
            <PlatformMockup />
          </div>
        </div>
      </div>
    </section>
  )
}
