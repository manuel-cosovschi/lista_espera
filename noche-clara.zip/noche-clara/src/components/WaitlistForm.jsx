import React, { useState } from 'react'
import { joinWaitlist } from '../lib/waitlist'

export default function WaitlistForm({ onSuccess, buttonText = 'Unirme a la lista de espera', compact = false }) {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [duplicate, setDuplicate] = useState(false)

  const validate = () => {
    if (!name.trim()) return 'Por favor ingresá tu nombre.'
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return 'Por favor ingresá un email válido.'
    return null
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    const validationError = validate()
    if (validationError) { setError(validationError); return }

    setLoading(true)
    setError('')
    setDuplicate(false)

    try {
      const result = await joinWaitlist({ name, email })
      if (result.duplicate) {
        setDuplicate(true)
      } else {
        onSuccess && onSuccess({ name, email })
      }
    } catch (err) {
      setError('Ocurrió un error. Por favor intentá de nuevo.')
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  if (duplicate) {
    return (
      <div
        className="glass-card-light p-5 text-center"
        style={{ animation: 'fadeUp 0.5s ease forwards' }}
      >
        <p className="text-lavender-300 text-sm">
          Ya estás en la lista de espera. Te avisaremos apenas abramos el acceso.
        </p>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className={`w-full ${compact ? 'space-y-3' : 'space-y-4'}`}>
      <div className={compact ? 'space-y-3' : 'grid grid-cols-1 sm:grid-cols-2 gap-3'}>
        <input
          type="text"
          placeholder="Tu nombre"
          value={name}
          onChange={e => setName(e.target.value)}
          className="input-night"
          disabled={loading}
        />
        <input
          type="email"
          placeholder="Tu email"
          value={email}
          onChange={e => setEmail(e.target.value)}
          className="input-night"
          disabled={loading}
        />
      </div>

      {error && (
        <p className="text-red-400/80 text-sm">{error}</p>
      )}

      <button
        type="submit"
        disabled={loading}
        className="btn-primary w-full flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed"
        style={{ fontFamily: 'DM Sans, sans-serif' }}
      >
        {loading ? (
          <>
            <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
              <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" strokeOpacity="0.3" />
              <path d="M12 2a10 10 0 0 1 10 10" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
            </svg>
            Guardando…
          </>
        ) : buttonText}
      </button>
    </form>
  )
}
