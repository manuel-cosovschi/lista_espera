import React from 'react'

export default function Footer() {
  return (
    <footer
      style={{
        borderTop: '1px solid rgba(200,192,232,0.07)',
        padding: '40px 24px',
      }}
    >
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-8">
          {/* Brand */}
          <div className="flex items-center gap-2">
            <span style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '16px', fontWeight: 400, color: 'rgba(247,241,227,0.5)' }}>
              Noche Clara
            </span>
            <span style={{ color: 'rgba(247,241,227,0.2)', fontSize: '13px' }}>·</span>
            <span style={{ color: 'rgba(247,241,227,0.3)', fontSize: '12px', fontFamily: 'DM Mono, monospace' }}>
              nocheclara.app
            </span>
          </div>

          {/* Social */}
          <div className="flex items-center gap-4">
            <a
              href="https://instagram.com/nocheclara.app"
              target="_blank"
              rel="noopener noreferrer"
              style={{ color: 'rgba(247,241,227,0.3)', fontSize: '12px', textDecoration: 'none', transition: 'color 0.2s' }}
              onMouseOver={e => e.currentTarget.style.color = 'rgba(200,192,232,0.7)'}
              onMouseOut={e => e.currentTarget.style.color = 'rgba(247,241,227,0.3)'}
            >
              Instagram
            </a>
            <a
              href="https://tiktok.com/@nocheclara.app"
              target="_blank"
              rel="noopener noreferrer"
              style={{ color: 'rgba(247,241,227,0.3)', fontSize: '12px', textDecoration: 'none', transition: 'color 0.2s' }}
              onMouseOver={e => e.currentTarget.style.color = 'rgba(200,192,232,0.7)'}
              onMouseOut={e => e.currentTarget.style.color = 'rgba(247,241,227,0.3)'}
            >
              TikTok
            </a>
            <a
              href="#"
              style={{ color: 'rgba(247,241,227,0.3)', fontSize: '12px', textDecoration: 'none', transition: 'color 0.2s' }}
              onMouseOver={e => e.currentTarget.style.color = 'rgba(200,192,232,0.7)'}
              onMouseOut={e => e.currentTarget.style.color = 'rgba(247,241,227,0.3)'}
            >
              Privacidad
            </a>
            <a
              href="#"
              style={{ color: 'rgba(247,241,227,0.3)', fontSize: '12px', textDecoration: 'none', transition: 'color 0.2s' }}
              onMouseOver={e => e.currentTarget.style.color = 'rgba(200,192,232,0.7)'}
              onMouseOut={e => e.currentTarget.style.color = 'rgba(247,241,227,0.3)'}
            >
              Términos
            </a>
          </div>
        </div>

        <p
          style={{
            textAlign: 'center',
            color: 'rgba(247,241,227,0.2)',
            fontSize: '11px',
            lineHeight: '1.6',
            fontWeight: 300,
            maxWidth: '600px',
            margin: '0 auto',
          }}
        >
          Producto educativo de bienestar. No reemplaza diagnóstico, tratamiento ni acompañamiento médico o psicológico profesional.
        </p>
      </div>
    </footer>
  )
}
