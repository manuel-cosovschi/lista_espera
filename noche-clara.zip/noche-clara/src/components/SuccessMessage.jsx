import React from 'react'

export default function SuccessMessage({ name }) {
  return (
    <div
      className="text-center py-8 px-4"
      style={{ animation: 'fadeUp 0.6s ease forwards' }}
    >
      {/* Moon icon */}
      <div className="flex justify-center mb-6">
        <div
          style={{
            width: '64px',
            height: '64px',
            borderRadius: '50%',
            background: 'radial-gradient(circle at 35% 35%, rgba(200,192,232,0.25) 0%, rgba(155,143,212,0.1) 60%, transparent 100%)',
            border: '1px solid rgba(200,192,232,0.25)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            animation: 'float 4s ease-in-out infinite',
          }}
        >
          <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
            <path
              d="M14 3C8 3 3 8 3 14C3 20 8 25 14 25C17 25 19.7 23.8 21.6 21.9C19.8 22.3 17.9 22 16.2 21.1C12.3 19 10.5 14.4 12.1 10.4C13.1 7.9 15.2 6.1 17.7 5.4C16.5 4 15.3 3 14 3Z"
              fill="rgba(200,192,232,0.6)"
            />
          </svg>
        </div>
      </div>

      <h3
        className="mb-3"
        style={{
          fontFamily: 'Cormorant Garamond, serif',
          fontSize: 'clamp(26px, 5vw, 36px)',
          fontWeight: 400,
          color: '#F7F1E3',
        }}
      >
        Ya estás dentro
        {name ? `, ${name.split(' ')[0]}` : ''}
      </h3>

      <p className="text-cream-300/70 text-sm leading-relaxed max-w-sm mx-auto mb-8">
        Te sumaste a la lista de espera de Noche Clara. Cuando abramos el acceso anticipado, vas a recibir un email con el beneficio de lanzamiento.
      </p>

      {/* Stars decoration */}
      <div className="flex justify-center gap-2 mb-8">
        {[1,2,3,4,5].map(i => (
          <svg key={i} width="12" height="12" viewBox="0 0 12 12" fill="none"
            style={{ opacity: 0.3 + i * 0.1, animationDelay: `${i * 0.2}s` }}>
            <path d="M6 1L7 4.5H10.5L7.8 6.5L8.8 10L6 8L3.2 10L4.2 6.5L1.5 4.5H5L6 1Z"
              fill="rgba(232,213,160,0.8)" />
          </svg>
        ))}
      </div>

      <a
        href="https://instagram.com/nocheclara.app"
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex items-center gap-2 px-6 py-3 rounded-full text-sm transition-all duration-300"
        style={{
          background: 'rgba(155,143,212,0.1)',
          border: '1px solid rgba(155,143,212,0.2)',
          color: '#C8C0E8',
          fontWeight: 400,
        }}
        onMouseOver={e => {
          e.currentTarget.style.background = 'rgba(155,143,212,0.18)'
          e.currentTarget.style.borderColor = 'rgba(155,143,212,0.35)'
        }}
        onMouseOut={e => {
          e.currentTarget.style.background = 'rgba(155,143,212,0.1)'
          e.currentTarget.style.borderColor = 'rgba(155,143,212,0.2)'
        }}
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <rect x="2" y="2" width="20" height="20" rx="5" />
          <circle cx="12" cy="12" r="4" />
          <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
        </svg>
        Seguir en Instagram
      </a>

      <p className="text-cream-300/30 text-xs mt-4">
        Mientras tanto, seguinos para ver avances de la plataforma.
      </p>
    </div>
  )
}
