import React from 'react'

function ProgressBar({ percent, color = '#9B8FD4' }) {
  return (
    <div style={{ background: 'rgba(255,255,255,0.06)', borderRadius: '99px', height: '4px', overflow: 'hidden' }}>
      <div style={{ width: `${percent}%`, height: '100%', background: color, borderRadius: '99px', transition: 'width 1s ease' }} />
    </div>
  )
}

export default function PlatformMockup() {
  return (
    <div
      className="animate-float"
      style={{
        width: '100%',
        maxWidth: '520px',
        perspective: '1000px',
      }}
    >
      {/* Browser chrome */}
      <div
        style={{
          background: '#0E1628',
          borderRadius: '12px',
          border: '1px solid rgba(200,192,232,0.12)',
          boxShadow: '0 32px 80px rgba(0,0,0,0.6), 0 0 80px rgba(155,143,212,0.08)',
          overflow: 'hidden',
          transform: 'rotateY(-4deg) rotateX(2deg)',
        }}
      >
        {/* Browser bar */}
        <div style={{ background: '#090F1F', padding: '10px 14px', display: 'flex', alignItems: 'center', gap: '8px', borderBottom: '1px solid rgba(200,192,232,0.06)' }}>
          <div style={{ display: 'flex', gap: '5px' }}>
            <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: 'rgba(255,255,255,0.08)' }} />
            <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: 'rgba(255,255,255,0.08)' }} />
            <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: 'rgba(255,255,255,0.08)' }} />
          </div>
          <div style={{ flex: 1, background: 'rgba(255,255,255,0.05)', borderRadius: '4px', padding: '3px 10px', fontSize: '10px', color: 'rgba(247,241,227,0.2)', fontFamily: 'DM Mono, monospace' }}>
            nocheclara.app/dashboard
          </div>
        </div>

        {/* App content */}
        <div style={{ display: 'flex', height: '340px' }}>
          {/* Sidebar */}
          <div style={{ width: '160px', background: 'rgba(6,11,24,0.8)', borderRight: '1px solid rgba(200,192,232,0.06)', padding: '16px 12px', display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <div style={{ fontFamily: 'Cormorant Garamond, serif', color: 'rgba(247,241,227,0.7)', fontSize: '13px', marginBottom: '8px', paddingBottom: '8px', borderBottom: '1px solid rgba(200,192,232,0.06)' }}>Noche Clara</div>
            {['Dashboard', 'Mi Programa', 'Tracker', 'Diario', 'Audios', 'Recursos'].map((item, i) => (
              <div key={item} style={{
                padding: '6px 10px',
                borderRadius: '6px',
                fontSize: '11px',
                color: i === 0 ? '#F7F1E3' : 'rgba(247,241,227,0.35)',
                background: i === 0 ? 'rgba(155,143,212,0.15)' : 'transparent',
                cursor: 'pointer',
                fontFamily: 'DM Sans, sans-serif',
                fontWeight: i === 0 ? 500 : 300,
              }}>
                {item}
              </div>
            ))}
          </div>

          {/* Main content */}
          <div style={{ flex: 1, padding: '16px', overflow: 'hidden' }}>
            {/* Header */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
              <div>
                <div style={{ fontSize: '10px', color: 'rgba(247,241,227,0.3)', fontFamily: 'DM Sans, sans-serif', marginBottom: '3px', letterSpacing: '0.08em' }}>BUENAS NOCHES</div>
                <div style={{ fontFamily: 'Cormorant Garamond, serif', color: '#F7F1E3', fontSize: '18px', fontWeight: 400 }}>Noche 14 de 21</div>
              </div>
              <div style={{ background: 'rgba(155,143,212,0.15)', border: '1px solid rgba(155,143,212,0.2)', borderRadius: '20px', padding: '4px 10px', fontSize: '10px', color: '#C8C0E8', fontFamily: 'DM Sans, sans-serif' }}>
                En progreso
              </div>
            </div>

            {/* Progress */}
            <div style={{ background: 'rgba(14,22,40,0.8)', borderRadius: '8px', padding: '12px', marginBottom: '12px', border: '1px solid rgba(200,192,232,0.06)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <span style={{ fontSize: '10px', color: 'rgba(247,241,227,0.4)', fontFamily: 'DM Sans, sans-serif' }}>Progreso del programa</span>
                <span style={{ fontSize: '10px', color: '#C8C0E8', fontFamily: 'DM Mono, monospace' }}>67%</span>
              </div>
              <ProgressBar percent={67} />
              <div style={{ display: 'flex', gap: '4px', marginTop: '10px', flexWrap: 'wrap' }}>
                {Array.from({ length: 21 }, (_, i) => (
                  <div key={i} style={{
                    width: '16px', height: '16px', borderRadius: '3px', fontSize: '7px',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    background: i < 14 ? 'rgba(155,143,212,0.4)' : i === 13 ? 'rgba(155,143,212,0.8)' : 'rgba(255,255,255,0.04)',
                    color: i < 14 ? '#C8C0E8' : 'rgba(247,241,227,0.15)',
                    fontFamily: 'DM Mono, monospace',
                    border: i === 13 ? '1px solid rgba(155,143,212,0.6)' : 'none',
                  }}>
                    {i + 1}
                  </div>
                ))}
              </div>
            </div>

            {/* Metrics row */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
              <div style={{ background: 'rgba(14,22,40,0.8)', borderRadius: '8px', padding: '10px', border: '1px solid rgba(200,192,232,0.06)' }}>
                <div style={{ fontSize: '9px', color: 'rgba(247,241,227,0.3)', fontFamily: 'DM Sans, sans-serif', marginBottom: '4px' }}>HORAS DORMIDAS</div>
                <div style={{ fontFamily: 'Cormorant Garamond, serif', color: '#F7F1E3', fontSize: '20px' }}>7.3</div>
                <ProgressBar percent={73} color="#C9A84C" />
              </div>
              <div style={{ background: 'rgba(14,22,40,0.8)', borderRadius: '8px', padding: '10px', border: '1px solid rgba(200,192,232,0.06)' }}>
                <div style={{ fontSize: '9px', color: 'rgba(247,241,227,0.3)', fontFamily: 'DM Sans, sans-serif', marginBottom: '4px' }}>CALIDAD</div>
                <div style={{ fontFamily: 'Cormorant Garamond, serif', color: '#F7F1E3', fontSize: '20px' }}>8/10</div>
                <ProgressBar percent={80} color="#9B8FD4" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
