import React, { useState } from 'react'
import Stars from './components/Stars'
import Navbar from './components/Navbar'
import HeroWaitlist from './components/HeroWaitlist'
import { BenefitCard, FeatureCard } from './components/Cards'
import WaitlistForm from './components/WaitlistForm'
import SuccessMessage from './components/SuccessMessage'
import FAQ from './components/FAQ'
import Footer from './components/Footer'

const benefits = [
  { icon: '⚡', title: 'Acceso anticipado', description: 'Entrás antes que el público general cuando abramos el lanzamiento.' },
  { icon: '✦', title: '70% de descuento', description: 'Tarifa especial de lanzamiento exclusiva para la lista de espera.' },
  { icon: '🌙', title: 'Novedades primero', description: 'Recibís actualizaciones del programa antes que nadie más.' },
  { icon: '◎', title: 'Cupos limitados', description: 'La primera ronda de acceso tiene cupos reducidos para primeros usuarios.' },
  { icon: '◈', title: 'Recursos bonus', description: 'Contenido exclusivo adicional para quienes se anotan antes del lanzamiento.' },
]

const features = [
  { icon: '🌙', title: 'Programa de 21 noches', description: 'Un recorrido guiado noche a noche para construir tu rutina de descanso.' },
  { icon: '📊', title: 'Tracker de sueño', description: 'Registrá tus horas, calidad y patrones para ver tu evolución.' },
  { icon: '📓', title: 'Diario nocturno', description: 'Espacio para cerrar el día, soltar preocupaciones y ordenar la cabeza.' },
  { icon: '🎧', title: 'Audios guiados', description: 'Meditaciones y recursos sonoros para bajar revoluciones antes de dormir.' },
  { icon: '📥', title: 'Workbook descargable', description: 'Ejercicios prácticos para trabajar tu rutina fuera de la plataforma.' },
  { icon: '✅', title: 'Checklist nocturna', description: 'Rituales simples y repetibles para cerrar cada noche con más calma.' },
]

const forWho = [
  'Te acostás cansado pero tu cabeza sigue prendida.',
  'Querés una rutina nocturna simple y repetible.',
  'Te cuesta ordenar el cierre del día.',
  'Querés hacer seguimiento de tu descanso.',
  'Preferís una guía práctica en vez de consejos sueltos.',
]

function SectionLabel({ children }) {
  return (
    <p className="text-lavender-400 text-xs tracking-widest uppercase mb-3" style={{ fontWeight: 400 }}>
      {children}
    </p>
  )
}

function SectionTitle({ children }) {
  return (
    <h2
      className="text-cream-100"
      style={{
        fontFamily: 'Cormorant Garamond, serif',
        fontSize: 'clamp(30px, 5vw, 48px)',
        fontWeight: 400,
        lineHeight: 1.15,
      }}
    >
      {children}
    </h2>
  )
}

export default function App() {
  const [ctaSuccess, setCtaSuccess] = useState(false)
  const [ctaData, setCtaData] = useState(null)

  return (
    <div className="relative min-h-screen bg-night-950 overflow-x-hidden">
      <div className="noise-overlay" />
      <Stars />

      <div className="relative z-10">
        <Navbar />

        {/* ── HERO ── */}
        <HeroWaitlist />

        {/* ── DIVIDER ── */}
        <div className="section-padding">
          <div className="max-w-6xl mx-auto border-t" style={{ borderColor: 'rgba(200,192,232,0.06)' }} />
        </div>

        {/* ── BENEFITS ── */}
        <section className="section-padding py-24">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-14">
              <SectionLabel>Lista de espera</SectionLabel>
              <SectionTitle>¿Por qué sumarte antes?</SectionTitle>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
              {benefits.map((b, i) => (
                <BenefitCard key={i} {...b} />
              ))}
            </div>
          </div>
        </section>

        {/* ── FEATURES ── */}
        <section className="section-padding py-24">
          <div className="max-w-6xl mx-auto">
            <div
              className="grid lg:grid-cols-2 gap-12 items-start"
            >
              <div>
                <SectionLabel>La plataforma</SectionLabel>
                <SectionTitle>Qué incluirá<br />Noche Clara</SectionTitle>
                <p className="text-cream-300/50 mt-5 text-sm leading-relaxed" style={{ fontWeight: 300, maxWidth: '380px' }}>
                  Todo lo que necesitás para construir una rutina nocturna estable, en un solo lugar.
                </p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {features.map((f, i) => (
                  <FeatureCard key={i} {...f} />
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* ── FOR WHO ── */}
        <section className="section-padding py-24">
          <div className="max-w-4xl mx-auto">
            <div
              className="glass-card p-10 md:p-14"
              style={{
                background: 'linear-gradient(135deg, rgba(14,22,40,0.9) 0%, rgba(19,30,53,0.8) 100%)',
                border: '1px solid rgba(200,192,232,0.1)',
              }}
            >
              <SectionLabel>Para quién es</SectionLabel>
              <SectionTitle className="mb-8">Esto es para vos si…</SectionTitle>

              <ul className="mt-8 space-y-4">
                {forWho.map((item, i) => (
                  <li key={i} className="flex items-start gap-4">
                    <span
                      style={{
                        color: 'rgba(155,143,212,0.5)',
                        fontSize: '8px',
                        marginTop: '8px',
                        flexShrink: 0,
                      }}
                    >
                      ◆
                    </span>
                    <span
                      className="text-cream-200/70 leading-relaxed"
                      style={{ fontSize: '16px', fontWeight: 300 }}
                    >
                      {item}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* ── FAQ ── */}
        <FAQ />

        {/* ── CTA FINAL ── */}
        <section className="section-padding py-24">
          <div className="max-w-2xl mx-auto text-center">
            {/* Stars decoration */}
            <div className="flex justify-center gap-3 mb-8">
              {[...Array(5)].map((_, i) => (
                <div
                  key={i}
                  className="w-px h-px rounded-full bg-lavender-400"
                  style={{
                    width: '3px',
                    height: '3px',
                    opacity: 0.2 + i * 0.15,
                    boxShadow: '0 0 6px rgba(155,143,212,0.8)',
                  }}
                />
              ))}
            </div>

            <SectionLabel>Lanzamiento</SectionLabel>
            <SectionTitle>Sé parte del lanzamiento<br />de Noche Clara</SectionTitle>
            <p className="text-cream-300/50 mt-5 mb-10 text-sm leading-relaxed" style={{ fontWeight: 300 }}>
              Sumate a la lista de espera y recibí el acceso anticipado cuando abramos el programa.
            </p>

            <div className="glass-card p-8 glow-lavender">
              {ctaSuccess ? (
                <SuccessMessage name={ctaData?.name} />
              ) : (
                <>
                  <WaitlistForm
                    onSuccess={(data) => { setCtaData(data); setCtaSuccess(true) }}
                    buttonText="Quiero acceso anticipado"
                    compact
                  />
                  <p className="text-cream-300/25 text-xs mt-5 leading-relaxed" style={{ fontWeight: 300 }}>
                    Producto educativo de bienestar. No reemplaza diagnóstico, tratamiento ni acompañamiento médico o psicológico profesional.
                  </p>
                </>
              )}
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </div>
  )
}
