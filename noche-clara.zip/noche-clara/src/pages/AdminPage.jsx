import React from 'react'
import AdminPanel from '../components/AdminPanel'
import Stars from '../components/Stars'

export default function AdminPage() {
  return (
    <div className="relative min-h-screen bg-night-950">
      <Stars />
      <div className="relative z-10">
        <AdminPanel />
      </div>
    </div>
  )
}
