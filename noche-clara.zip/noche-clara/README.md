# Noche Clara — Landing de Lista de Espera

Plataforma web de bienestar y descanso. Landing page para captar emails antes del lanzamiento.

---

## Stack

- **Frontend**: React + Vite + Tailwind CSS
- **Base de datos**: Supabase (PostgreSQL)
- **Email**: Resend (recomendado) — fácil de configurar, gratis hasta 3000 emails/mes
- **Deploy**: Vercel (con serverless functions para emails)
- **Pagos**: Hotmart (link externo)

---

## Instalación

```bash
# 1. Clonar o descomprimir el proyecto
cd noche-clara

# 2. Instalar dependencias
npm install

# 3. Copiar variables de entorno
cp .env.example .env

# 4. Completar el .env con tus credenciales (ver secciones abajo)

# 5. Desarrollo local
npm run dev

# 6. Build para producción
npm run build
```

---

## Configurar Supabase

### 1. Crear proyecto

1. Ir a [supabase.com](https://supabase.com) → **New project**
2. Elegir nombre: `noche-clara`
3. Guardar la contraseña generada

### 2. Crear la tabla

1. Ir a **SQL Editor** → **New Query**
2. Copiar y ejecutar el contenido de `supabase-setup.sql`

### 3. Obtener las claves

En **Project Settings → API**:

```env
VITE_SUPABASE_URL=https://xxxxxxxxxxxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

> ⚠️ El `SERVICE_ROLE_KEY` nunca debe exponerse en el cliente. Solo va en las funciones serverless.

---

## Configurar Resend (email)

### 1. Crear cuenta

1. Ir a [resend.com](https://resend.com) → registrarse gratis
2. Plan gratuito: 3.000 emails/mes, perfecto para empezar

### 2. Verificar dominio

1. En Resend → **Domains** → **Add Domain**
2. Agregar `nocheclara.app`
3. Agregar los registros DNS que Resend indica (en tu proveedor de dominio)
4. Verificar que esté activo (puede tardar algunos minutos)

### 3. Crear API Key

1. En Resend → **API Keys** → **Create API Key**
2. Copiar la key

```env
EMAIL_PROVIDER_API_KEY=re_xxxxxxxxxxxxxxxxxxxx
FROM_EMAIL=hola@nocheclara.app
```

> Si no tenés dominio verificado todavía, podés usar `onboarding@resend.dev` para pruebas.

---

## Configurar Hotmart

1. Crear tu producto en [hotmart.com](https://hotmart.com)
2. Obtener el link de checkout del producto
3. Agregar al `.env`:

```env
HOTMART_CHECKOUT_URL=https://pay.hotmart.com/TU-LINK-REAL
LAUNCH_DISCOUNT_PERCENT=70
```

---

## Deploy en Vercel

### 1. Instalar Vercel CLI

```bash
npm i -g vercel
```

### 2. Deploy

```bash
vercel
```

Seguir las instrucciones. En el primer deploy Vercel detecta automáticamente que es un proyecto Vite.

### 3. Variables de entorno en Vercel

En [vercel.com](https://vercel.com) → tu proyecto → **Settings → Environment Variables**:

Agregar todas las variables del `.env`:

| Variable | Dónde se usa |
|---|---|
| `VITE_SUPABASE_URL` | Cliente + serverless |
| `VITE_SUPABASE_ANON_KEY` | Cliente |
| `SUPABASE_SERVICE_ROLE_KEY` | Solo serverless |
| `EMAIL_PROVIDER_API_KEY` | Solo serverless |
| `FROM_EMAIL` | Solo serverless |
| `HOTMART_CHECKOUT_URL` | Solo serverless |
| `LAUNCH_DISCOUNT_PERCENT` | Solo serverless |
| `ADMIN_SECRET` | Solo serverless |

> Las variables que empiezan con `VITE_` son públicas (se incluyen en el bundle del cliente). Las demás son privadas.

### 4. Dominio personalizado

En Vercel → **Settings → Domains** → agregar `nocheclara.app`

---

## Panel de Admin

Acceder en: `https://nocheclara.app/admin`

- Autenticarse con `ADMIN_SECRET`
- Ver cantidad de personas en lista
- Ver últimos registros
- Enviar emails de lanzamiento

---

## Enviar emails de lanzamiento manualmente

También se puede hacer con `curl`:

```bash
curl -X POST https://nocheclara.app/api/send-launch-emails \
  -H "Content-Type: application/json" \
  -d '{"adminSecret": "TU_ADMIN_SECRET"}'
```

Respuesta:
```json
{
  "sent": 42,
  "total": 42
}
```

---

## Estructura del proyecto

```
noche-clara/
├── api/
│   ├── send-confirmation.js      # Email de confirmación (serverless)
│   └── send-launch-emails.js     # Email de lanzamiento (serverless)
├── src/
│   ├── components/
│   │   ├── AdminPanel.jsx
│   │   ├── Cards.jsx             # BenefitCard + FeatureCard
│   │   ├── FAQ.jsx
│   │   ├── Footer.jsx
│   │   ├── HeroWaitlist.jsx
│   │   ├── Navbar.jsx
│   │   ├── PlatformMockup.jsx
│   │   ├── Stars.jsx
│   │   ├── SuccessMessage.jsx
│   │   └── WaitlistForm.jsx
│   ├── lib/
│   │   ├── supabase.js           # Cliente de Supabase
│   │   └── waitlist.js           # Lógica de lista de espera
│   ├── pages/
│   │   └── AdminPage.jsx
│   ├── App.jsx                   # Landing page completa
│   ├── index.css
│   └── main.jsx
├── .env.example
├── supabase-setup.sql
├── vercel.json
├── vite.config.js
├── tailwind.config.js
└── package.json
```

---

## Flujo de un registro

1. Usuario completa nombre + email en el formulario
2. Se valida localmente (nombre no vacío, email válido)
3. Se consulta Supabase para verificar duplicados
4. Si es nuevo: se inserta en la tabla `waitlist`
5. Se llama a `/api/send-confirmation` (serverless)
6. La función envía el email de confirmación via Resend
7. Se marca `confirmation_email_sent = true` en Supabase
8. Se muestra el mensaje de éxito en la UI

---

## Notas

- El proyecto funciona sin las variables de email configuradas (el formulario guarda igual, solo falla el email silenciosamente)
- Para desarrollo local, las funciones serverless no corren con `npm run dev`. Usar `vercel dev` para probarlas localmente
- Resend es el proveedor recomendado por su simplicidad. También se puede usar Brevo (ex-Sendinblue), MailerLite o SendGrid cambiando la función `sendEmailWithResend` en las funciones serverless
