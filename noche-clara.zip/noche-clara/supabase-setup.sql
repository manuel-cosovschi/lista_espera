-- ============================================================
-- NOCHE CLARA — Supabase Setup
-- Ejecutar en: supabase.com → SQL Editor → New Query
-- ============================================================

-- Tabla principal de lista de espera
CREATE TABLE IF NOT EXISTS waitlist (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  source TEXT DEFAULT 'landing',
  status TEXT DEFAULT 'waiting' CHECK (status IN ('waiting', 'invited', 'purchased')),
  launch_email_sent BOOLEAN DEFAULT false NOT NULL,
  confirmation_email_sent BOOLEAN DEFAULT false NOT NULL
);

-- Índice en email para búsquedas rápidas
CREATE INDEX IF NOT EXISTS idx_waitlist_email ON waitlist(email);
CREATE INDEX IF NOT EXISTS idx_waitlist_status ON waitlist(status);
CREATE INDEX IF NOT EXISTS idx_waitlist_created ON waitlist(created_at DESC);

-- Row Level Security
ALTER TABLE waitlist ENABLE ROW LEVEL SECURITY;

-- Política: usuarios anónimos pueden insertar (necesario para el formulario)
CREATE POLICY "Allow anonymous insert" ON waitlist
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Política: usuarios anónimos pueden leer solo para verificar duplicados de su propio email
-- (el check de duplicado se hace con anon key, solo leen su propio registro)
CREATE POLICY "Allow read own email" ON waitlist
  FOR SELECT
  TO anon
  USING (true);

-- NOTA: El service_role key (usado en las serverless functions) bypasea RLS automáticamente.
-- No necesita políticas adicionales para las funciones de admin.

-- ============================================================
-- VERIFICACIÓN: ejecutar estas queries para confirmar setup
-- ============================================================

-- SELECT * FROM waitlist LIMIT 5;
-- SELECT COUNT(*) FROM waitlist;
