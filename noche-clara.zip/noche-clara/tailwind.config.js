/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        night: {
          950: '#060B18',
          900: '#090F1F',
          800: '#0E1628',
          700: '#131E35',
          600: '#1A2844',
        },
        cream: {
          50: '#FDFAF4',
          100: '#F7F1E3',
          200: '#EDE3CC',
          300: '#DDD0B3',
        },
        lavender: {
          200: '#C8C0E8',
          300: '#B5A9E0',
          400: '#9B8FD4',
          500: '#7E72C0',
        },
        gold: {
          200: '#E8D5A0',
          300: '#DFC078',
          400: '#C9A84C',
        },
      },
      fontFamily: {
        display: ['"Cormorant Garamond"', 'serif'],
        body: ['"DM Sans"', 'sans-serif'],
        mono: ['"DM Mono"', 'monospace'],
      },
      animation: {
        'float': 'float 6s ease-in-out infinite',
        'twinkle': 'twinkle 3s ease-in-out infinite',
        'fade-up': 'fadeUp 0.7s ease forwards',
        'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-12px)' },
        },
        twinkle: {
          '0%, 100%': { opacity: '0.2' },
          '50%': { opacity: '1' },
        },
        fadeUp: {
          '0%': { opacity: '0', transform: 'translateY(24px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
    },
  },
  plugins: [],
}
