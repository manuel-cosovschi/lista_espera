// api/send-confirmation.js
// Vercel Serverless Function
// POST /api/send-confirmation

import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.VITE_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

async function sendEmailWithResend({ to, name }) {
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${process.env.EMAIL_PROVIDER_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      from: process.env.FROM_EMAIL || 'hola@nocheclara.app',
      to,
      subject: 'Ya estás en la lista de espera de Noche Clara',
      html: `
        <div style="font-family: Georgia, serif; max-width: 520px; margin: 0 auto; padding: 40px 24px; background: #090F1F; color: #F7F1E3;">
          <div style="margin-bottom: 32px;">
            <h2 style="font-size: 28px; font-weight: 400; color: #F7F1E3; margin: 0 0 8px 0;">Noche Clara</h2>
            <div style="width: 40px; height: 1px; background: rgba(155,143,212,0.4);"></div>
          </div>

          <p style="font-size: 16px; color: rgba(247,241,227,0.8); margin-bottom: 24px;">Hola ${name},</p>

          <p style="font-size: 15px; color: rgba(247,241,227,0.65); line-height: 1.7; margin-bottom: 16px;">
            Gracias por sumarte a la lista de espera de Noche Clara.
          </p>

          <p style="font-size: 15px; color: rgba(247,241,227,0.65); line-height: 1.7; margin-bottom: 16px;">
            Estamos preparando una plataforma web para ayudarte a ordenar tu rutina nocturna con un programa guiado de 21 noches, tracker de sueño, diario nocturno, audios y recursos descargables.
          </p>

          <p style="font-size: 15px; color: rgba(247,241,227,0.65); line-height: 1.7; margin-bottom: 32px;">
            Como parte de la lista de espera, vas a recibir acceso anticipado cuando abramos el lanzamiento y una tarifa especial con <strong style="color: #C8C0E8;">70% de descuento</strong>.
          </p>

          <p style="font-size: 15px; color: rgba(247,241,227,0.65); line-height: 1.7; margin-bottom: 40px;">
            Te vamos a avisar apenas esté disponible.
          </p>

          <div style="border-top: 1px solid rgba(200,192,232,0.1); padding-top: 24px;">
            <p style="font-size: 13px; color: rgba(247,241,227,0.3); margin: 0 0 8px 0;">
              Equipo Noche Clara
            </p>
            <p style="font-size: 11px; color: rgba(247,241,227,0.2); margin: 0;">
              Producto educativo de bienestar. No reemplaza diagnóstico, tratamiento ni acompañamiento médico o psicológico profesional.
            </p>
          </div>
        </div>
      `,
    }),
  })

  if (!res.ok) {
    const err = await res.text()
    throw new Error(`Resend error: ${err}`)
  }
  return res.json()
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  const { name, email, id } = req.body

  if (!name || !email || !id) {
    return res.status(400).json({ error: 'Missing fields' })
  }

  try {
    await sendEmailWithResend({ to: email, name })

    // Mark confirmation sent
    await supabase
      .from('waitlist')
      .update({ confirmation_email_sent: true })
      .eq('id', id)

    return res.status(200).json({ ok: true })
  } catch (error) {
    console.error('Confirmation email error:', error)
    return res.status(500).json({ error: error.message })
  }
}
