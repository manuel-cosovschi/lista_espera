// api/send-launch-emails.js
// Vercel Serverless Function
// POST /api/send-launch-emails
// Protected by ADMIN_SECRET env var

import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.VITE_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

const hotmartUrl = process.env.HOTMART_CHECKOUT_URL || 'https://pay.hotmart.com/TU-LINK-DE-CHECKOUT'
const discountPercent = process.env.LAUNCH_DISCOUNT_PERCENT || '70'

async function sendLaunchEmail({ to, name }) {
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${process.env.EMAIL_PROVIDER_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      from: process.env.FROM_EMAIL || 'hola@nocheclara.app',
      to,
      subject: 'Noche Clara abrió el acceso anticipado',
      html: `
        <div style="font-family: Georgia, serif; max-width: 520px; margin: 0 auto; padding: 40px 24px; background: #090F1F; color: #F7F1E3;">
          <div style="margin-bottom: 32px;">
            <h2 style="font-size: 28px; font-weight: 400; color: #F7F1E3; margin: 0 0 8px 0;">Noche Clara</h2>
            <div style="width: 40px; height: 1px; background: rgba(155,143,212,0.4);"></div>
          </div>

          <p style="font-size: 16px; color: rgba(247,241,227,0.8); margin-bottom: 24px;">Hola ${name},</p>

          <p style="font-size: 15px; color: rgba(247,241,227,0.65); line-height: 1.7; margin-bottom: 24px;">
            Ya abrimos el acceso anticipado a Noche Clara.
          </p>

          <p style="font-size: 15px; color: rgba(247,241,227,0.65); line-height: 1.7; margin-bottom: 24px;">
            Durante el lanzamiento, las personas de la lista de espera pueden acceder con <strong style="color: #C8C0E8;">${discountPercent}% de descuento</strong>.
          </p>

          <div style="background: rgba(14,22,40,0.8); border: 1px solid rgba(200,192,232,0.1); border-radius: 12px; padding: 20px; margin-bottom: 24px;">
            <p style="font-size: 13px; color: rgba(200,192,232,0.6); margin: 0 0 12px 0; letter-spacing: 0.08em; text-transform: uppercase;">Noche Clara incluye</p>
            <ul style="margin: 0; padding-left: 16px; color: rgba(247,241,227,0.6); font-size: 14px; line-height: 2;">
              <li>Programa guiado de 21 noches</li>
              <li>Tracker de sueño</li>
              <li>Diario nocturno</li>
              <li>Audios guiados</li>
              <li>Workbook descargable</li>
              <li>Checklist nocturna</li>
              <li>Recursos para ordenar tu rutina</li>
            </ul>
          </div>

          <a
            href="${hotmartUrl}"
            style="display: block; text-align: center; background: rgba(155,143,212,0.85); color: #090F1F; text-decoration: none; padding: 16px 32px; border-radius: 999px; font-family: sans-serif; font-size: 15px; font-weight: 500; margin-bottom: 24px;"
          >
            Acceder a Noche Clara →
          </a>

          <p style="font-size: 13px; color: rgba(247,241,227,0.35); text-align: center; margin-bottom: 32px;">
            Este beneficio estará disponible por tiempo limitado para la lista de espera.
          </p>

          <div style="border-top: 1px solid rgba(200,192,232,0.1); padding-top: 24px;">
            <p style="font-size: 13px; color: rgba(247,241,227,0.3); margin: 0 0 8px 0;">
              Nos vemos dentro,<br/>Equipo Noche Clara
            </p>
            <p style="font-size: 11px; color: rgba(247,241,227,0.2); margin: 0;">
              Nota: Noche Clara es un producto educativo de bienestar. No reemplaza atención médica ni psicológica profesional.
            </p>
          </div>
        </div>
      `,
    }),
  })

  if (!res.ok) {
    const err = await res.text()
    throw new Error(`Resend error: ${err}`)
  }
  return res.json()
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  const { adminSecret } = req.body

  if (!adminSecret || adminSecret !== process.env.ADMIN_SECRET) {
    return res.status(401).json({ error: 'Unauthorized' })
  }

  try {
    // Fetch users pending launch email
    const { data: users, error } = await supabase
      .from('waitlist')
      .select('id, name, email')
      .eq('launch_email_sent', false)

    if (error) throw error
    if (!users?.length) {
      return res.status(200).json({ sent: 0, message: 'No hay usuarios pendientes' })
    }

    let sent = 0
    let errors = []

    for (const user of users) {
      try {
        await sendLaunchEmail({ to: user.email, name: user.name })
        await supabase
          .from('waitlist')
          .update({ launch_email_sent: true, status: 'invited' })
          .eq('id', user.id)
        sent++
      } catch (err) {
        errors.push({ email: user.email, error: err.message })
      }

      // Rate limit: 2 emails/sec
      await new Promise(r => setTimeout(r, 500))
    }

    return res.status(200).json({
      sent,
      total: users.length,
      errors: errors.length ? errors : undefined,
    })
  } catch (error) {
    console.error('Launch email error:', error)
    return res.status(500).json({ error: error.message })
  }
}
